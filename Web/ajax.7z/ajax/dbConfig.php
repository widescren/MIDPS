<?php
// Database configuration
$dbHost = "byethost33.com";
$dbUsername = "b33_17761899";
$dbPassword = "asdfghjkl";
$dbName = "codexworld";

// Create database connection
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>